package com.yash.springmvc;

import java.math.BigDecimal; 
import java.net.URI; 
import java.util.LinkedHashMap;
import java.util.List;
import org.joda.time.LocalDate;
import org.springframework.web.client.RestTemplate;
import com.yash.springmvc.model.Employee;
 
public class SpringRestTestClientEmployee {
 
    public static final String REST_SERVICE_URI = "http://localhost:8080/SpringMVCRestCRUD";
     
    /* GET */
    @SuppressWarnings("unchecked")
    private static void listAllEmployees(){
        System.out.println("Testing listAllEmployees API-----------");
         
        RestTemplate restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> employeesMap = restTemplate.getForObject(REST_SERVICE_URI+"/employees/", List.class);
         
        if(employeesMap!=null){
            for(LinkedHashMap<String, Object> map : employeesMap){
                System.out.println("Employee : id="+map.get("id")+", Name="+map.get("name")+", salary="+map.get("salary")+", joiningDate="+map.get("joiningDate"));;
            }
        }else{
            System.out.println("No Employee exist----------");
        }
    }
     
    /* GET */
    private static void getEmployee(){
        System.out.println("Testing getEmployee API----------");
        RestTemplate restTemplate = new RestTemplate();
        Employee employee = restTemplate.getForObject(REST_SERVICE_URI+"/employee/1", Employee.class);
        System.out.println(employee);
    }
     
    /* POST */
    private static void createEmployee() {
        System.out.println("Testing create Employee API----------");
        RestTemplate restTemplate = new RestTemplate();
        Employee employee = new Employee();
        employee.setId(10);
        employee.setName("Shital");
        employee.setJoiningDate(new LocalDate());
        employee.setSalary(new BigDecimal("25000"));
        employee.setSsn("12");
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI+"/employee/", employee, Employee.class);
        System.out.println("Location : "+uri.toASCIIString());
    }
 
    /* PUT */
    private static void updateEmployee() {
        System.out.println("Testing update Employee API----------");
        RestTemplate restTemplate = new RestTemplate();
        Employee employee  = new Employee();
        employee.setId(10);
        employee.setName("Shital Shinde");
        employee.setJoiningDate(new LocalDate());
        employee.setSalary(new BigDecimal("30000"));
        employee.setSsn("120");
        restTemplate.put(REST_SERVICE_URI+"/employee/1", employee);
        System.out.println(employee);
    }
 
    /* DELETE */
    private static void deleteEmployee() {
        System.out.println("Testing delete Employee API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/employee/1");
    }
 
 
    /* DELETE */
    private static void deleteAllEmployees() {
        System.out.println("Testing all delete Users API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI+"/employee/");
    }
 
    public static void main(String args[]){
    	listAllEmployees();
    	getEmployee();
    	createEmployee();
        listAllEmployees();
        updateEmployee();
        listAllEmployees();
        deleteEmployee();
        listAllEmployees();
        deleteAllEmployees();
        listAllEmployees();
    }
}
