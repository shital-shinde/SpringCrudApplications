package com.example.okta15x.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SecureController {

    public static final String AUTHENTICATED_PATH = "/authenticated";

    @RequestMapping(AUTHENTICATED_PATH)
    @PreAuthorize("#oauth2.hasScope('openid')")
    public String authenticated() {
        return "authenticated";
    }

    @RequestMapping("/users")
    @PreAuthorize("hasAuthority('User')")
    public String users() {
        return "roles";
    }

    @RequestMapping("/admins")
    @PreAuthorize("hasAuthority('Admin')")
    public String admins() {
        return "roles";
    }

    @RequestMapping("/403")
    public String error403() {
        return "403";
    }
}
