package com.example.okta15x.controller;

import org.springframework.stereotype.Controller; 
import org.springframework.web.bind.annotation.GetMapping;
import java.security.Principal;

@Controller
public class WebController {
        
	@GetMapping("/message")
	public String home(Principal principal){
		return "You are logged in, "+principal.getName()
		+" (Principle class: )"+principal.getClass().getName();
	}    
}
