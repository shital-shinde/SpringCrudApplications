package com.example.okta15x.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.okta.spring.config.OktaClientProperties;
import com.okta.spring.config.OktaOAuth2Properties;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;

@Controller
public class HomeController {

    private final OktaOAuth2Properties oktaOAuth2Properties;
    private final OktaClientProperties oktaClientProperties;

    public HomeController(OktaOAuth2Properties oktaOAuth2Properties, OktaClientProperties oktaClientProperties) {
        this.oktaOAuth2Properties = oktaOAuth2Properties;
        this.oktaClientProperties = oktaClientProperties;
    }

    @RequestMapping("/")
    public String home(Principal principal) {
        if (principal != null) {
            return "redirect:" + SecureController.AUTHENTICATED_PATH;
        }
        return "home";
    }

    @RequestMapping("/login")
    public String login(
        Model model,
        HttpServletRequest request,
        @RequestParam(name = "state", required = false) String springState
    ) {
        if (springState == null) {
            return "redirect:" + oktaOAuth2Properties.getRedirectUri();
        }
        model.addAttribute("state", springState);
        model.addAttribute("redirectUri",
            request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() +
            request.getContextPath() + oktaOAuth2Properties.getRedirectUri()
        );
        model.addAttribute("clientId", oktaOAuth2Properties.getClientId());
        model.addAttribute("issuer", oktaOAuth2Properties.getIssuer());
        model.addAttribute("scopes", oktaOAuth2Properties.getScopes());
        model.addAttribute("baseUrl", oktaClientProperties.getOrgUrl());
        return "login";
    }
}
