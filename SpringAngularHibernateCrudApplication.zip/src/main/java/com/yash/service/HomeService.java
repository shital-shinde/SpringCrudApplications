package com.yash.service;

public interface HomeService {

}
