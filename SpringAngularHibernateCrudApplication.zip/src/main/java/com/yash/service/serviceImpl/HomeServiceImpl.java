package com.yash.service.serviceImpl;

import com.yash.service.HomeService;

public class HomeServiceImpl implements HomeService{

}
