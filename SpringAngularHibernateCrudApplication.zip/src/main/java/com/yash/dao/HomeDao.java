package com.yash.dao;

public interface HomeDao {

}
