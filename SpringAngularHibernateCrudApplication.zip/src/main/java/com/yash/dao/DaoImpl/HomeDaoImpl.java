package com.yash.dao.DaoImpl;

import com.yash.dao.HomeDao;

public class HomeDaoImpl implements HomeDao{

}
