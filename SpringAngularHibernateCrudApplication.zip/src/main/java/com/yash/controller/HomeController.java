package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller; 
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.yash.model.DevProfileBeanImpl;
import com.yash.model.ProdProfileBeanImpl;
import com.yash.model.ProfileBean;

@Controller
public class HomeController {

	@Autowired
	ProfileBean profileBean;
	
	@Value("${server.port}")
	String applicationProperties1;

	@Value("${basic.message1}")
	String applicationProperties2;

	@Value("${basic.message2}")
	String applicationProperties3;
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String getHomePage(ModelMap modelMap){
		modelMap.put("message", "Welcome to home page....user!!!");
		return "home";
	}
	
	@RequestMapping(value="/again", method = RequestMethod.GET)
	public String getHomePageAgain(ModelMap modelMap){
		modelMap.put("message", "Welcome to home page....again....user!!!");
		return "home1";
	}

	@RequestMapping(value="/profile", method = RequestMethod.GET)
	public String showProfile(ModelMap modelMap){
		//modelMap.put("message", profileBean.configureProfileBean()+"<br>Server Port: "+applicationProperties1+"<br>Message1: "+applicationProperties2+"<br>Message2: "+applicationProperties3);
		modelMap.put("message", profileBean.configureProfileBean()
				+"<br>Server Port: "+applicationProperties1
				+(profileBean instanceof DevProfileBeanImpl ? 
						"<br>Message1: "+((DevProfileBeanImpl)profileBean).message1+"<br>Message2: "+((DevProfileBeanImpl)profileBean).message2
					  : "<br>Message1: "+((ProdProfileBeanImpl)profileBean).message1+"<br>Message2: "+((ProdProfileBeanImpl)profileBean).message2));
		return "home1";
	}
}
