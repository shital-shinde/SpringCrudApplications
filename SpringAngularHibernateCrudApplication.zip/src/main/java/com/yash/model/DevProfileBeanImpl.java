package com.yash.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Configuration
@Profile("dev")
//@PropertySource("classpath:application-dev.properties")
@ConfigurationProperties(prefix = "basic")
public class DevProfileBeanImpl implements ProfileBean{
	public String message1;
	public String message2;

	public String getMessage1() {
		return message1;
	}

	public void setMessage1(String message1) {
		this.message1 = message1;
	}

	public String getMessage2() {
		return message2;
	}

	public void setMessage2(String message2) {
		this.message2 = message2;
	}	
	@Override
	public String configureProfileBean() {
		System.out.println("Setting up datasource for DEV environment. ");
		return "Setting up datasource for DEV environment.";
	}
	
}
