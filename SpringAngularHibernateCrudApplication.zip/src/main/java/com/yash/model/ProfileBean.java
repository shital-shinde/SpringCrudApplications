package com.yash.model;

public interface ProfileBean {
	String configureProfileBean();
}
